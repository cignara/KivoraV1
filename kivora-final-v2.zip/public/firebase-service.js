/**
 * Kivora Learning — Firebase Service Layer
 * firebase-service.js  v1.0
 *
 * Single source of truth for all auth + database operations.
 * Replaces all localStorage-based auth and progress tracking in:
 *   - index.html  (handleLogin, socialLogin, localStorage.kivora_user)
 *   - kivora-activity-player.html  (saveProgress, getProgress, loadProgress)
 *
 * ═══════════════════════════════════════════════════════════════
 * DESIGN PRINCIPLES
 * ═══════════════════════════════════════════════════════════════
 * 1. COPPA: children never have their own Auth accounts.
 *    All child data lives under /users/{parentUid}/children/{childId}.
 *    Minimal PII: display name only — no surname, no birthdate, no email.
 *
 * 2. Atomic counters: XP, coins, stars, gems use FieldValue.increment().
 *    NEVER let the client read-calculate-write aggregate totals.
 *    This prevents race conditions across concurrent tabs/devices.
 *
 * 3. Idempotency: saveActivityProgress checks for an existing doc
 *    before writing. Calling it twice for the same activity is safe.
 *
 * 4. Dashboard efficiency:
 *    - Child dashboard: 3 parallel reads (child doc, recent activity, badges)
 *    - Parent dashboard: children array + Promise.all for world summaries
 *    - Teacher dashboard: single roster collection query (no N+1 reads)
 *      The roster doc holds a denormalized student summary, maintained
 *      by Cloud Functions whenever activityProgress is written.
 *
 * 5. Security: Firestore rules enforce field-level access control.
 *    Do not rely solely on client-side validation.
 *
 * ═══════════════════════════════════════════════════════════════
 * CLOUD FUNCTIONS DEPENDENCY
 * ═══════════════════════════════════════════════════════════════
 * Several collections are READ-ONLY from the client because they
 * are maintained by Cloud Functions (server-side triggers):
 *   - /worldProgress         → onActivityCompleted trigger
 *   - /badges                → badge engine trigger
 *   - /roster (summary cols) → onActivityCompleted trigger
 *   - /users plan field      → payment webhook trigger
 * See firebase-functions-spec.md for the full Cloud Functions spec.
 */

import {
  GoogleAuthProvider,
  OAuthProvider,
  signInWithPopup,
  signOut as fbSignOut,
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
}                          from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';

import {
  doc, collection,
  setDoc, getDoc, getDocs, updateDoc, deleteDoc,
  addDoc, writeBatch, runTransaction, onSnapshot,
  query, where, orderBy, limit,
  serverTimestamp, increment, Timestamp,
}                          from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

import { auth, db }        from './firebase-config.js';


// ═══════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════

export const WORLDS = [
  'alphabet-island',     // 110 activities
  'math-mountain',       // 130
  'story-cove',          //  80
  'creativity-kingdom',  //  65
  'science-safari',      // 120
  'life-skills-village', //  90
  'coding-city',         // 100
  'music-meadow',        //  80
  'brain-game-galaxy',   //  65
];

// Source of truth from Master Activity Plan v4
export const WORLD_ACTIVITY_TOTALS = {
  'alphabet-island':     110,
  'math-mountain':       130,
  'story-cove':           80,
  'creativity-kingdom':   65,
  'science-safari':      120,
  'life-skills-village':  90,
  'coding-city':         100,
  'music-meadow':         80,
  'brain-game-galaxy':    65,
};

// Reward values per difficulty — used for server-side validation
// Client must not invent XP values; these are the only valid ones.
export const DIFFICULTY_REWARDS = {
  'pre-easy':    { xp:  5, coins:  3, gems: 0 },
  'easy':        { xp: 10, coins:  5, gems: 0 },
  'intermediate':{ xp: 20, coins: 10, gems: 0 },
  'advanced':    { xp: 35, coins: 15, gems: 1 },
  'master':      { xp: 50, coins: 25, gems: 2 },
};
export const PERFECT_BONUS = { xp: 10, coins: 5 };

// XP thresholds per level. Threshold doubles every 5 levels, capped at L50.
function _calcLevelData(totalXP) {
  let xp = totalXP || 0;
  let level = 1;
  let threshold = 100;
  while (xp >= threshold && level < 50) {
    xp -= threshold;
    level++;
    if (level % 5 === 0) threshold = Math.floor(threshold * 1.5);
  }
  return { level, xpIntoLevel: xp, xpRequired: threshold, percent: Math.round((xp / threshold) * 100) };
}
export const calcLevel = (totalXP) => _calcLevelData(totalXP).level;
export const calcLevelData = _calcLevelData;


// ═══════════════════════════════════════════════════════════════════════
// AUTH SERVICE
// Handles Google / Apple / Microsoft / email sign-in.
// On first login: creates /users/{uid} document.
// On subsequent logins: updates lastLoginAt only (merge-safe).
// ═══════════════════════════════════════════════════════════════════════

export const AuthService = {

  async signInWithGoogle() {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const result = await signInWithPopup(auth, provider);
    await this._ensureUserDocument(result.user, 'google');
    return result.user;
  },

  async signInWithApple() {
    const provider = new OAuthProvider('apple.com');
    provider.addScope('email');
    provider.addScope('name');
    const result = await signInWithPopup(auth, provider);
    await this._ensureUserDocument(result.user, 'apple');
    return result.user;
  },

  async signInWithMicrosoft() {
    const provider = new OAuthProvider('microsoft.com');
    provider.addScope('email');
    const result = await signInWithPopup(auth, provider);
    await this._ensureUserDocument(result.user, 'microsoft');
    return result.user;
  },

  async signInWithEmail(email, password) {
    const result = await signInWithEmailAndPassword(auth, email, password);
    await this._ensureUserDocument(result.user, 'email');
    return result.user;
  },

  /**
   * Register new account. Role must be 'parent' or 'teacher'.
   * Child accounts are never created in Firebase Auth.
   */
  async registerWithEmail(email, password, role = 'parent') {
    if (!['parent', 'teacher'].includes(role)) throw new Error('Invalid role');
    const result = await createUserWithEmailAndPassword(auth, email, password);
    await this._createUserDocument(result.user, 'email', role);
    return result.user;
  },

  async signOut() {
    // End any active screen-time session before signing out
    const user = auth.currentUser;
    if (user && window._kivoraSessionStart) {
      const childId = window._kivoraActiveChildId;
      if (childId) {
        await ScreenTimeService.endSession(user.uid, childId, window._kivoraSessionStart).catch(() => {});
      }
    }
    await fbSignOut(auth);
  },

  getCurrentUser() {
    return auth.currentUser;
  },

  /**
   * Subscribe to auth state. Returns an unsubscribe function.
   * Call this in your app's init — drives all dashboard routing.
   */
  onAuthStateChanged(callback) {
    return onAuthStateChanged(auth, callback);
  },

  // ── Internal ──────────────────────────────────────────────────────────

  async _ensureUserDocument(firebaseUser, provider) {
    const userRef = doc(db, 'users', firebaseUser.uid);
    const snap    = await getDoc(userRef);
    if (!snap.exists()) {
      await this._createUserDocument(firebaseUser, provider, 'parent');
    } else {
      // Do NOT overwrite role, plan, or createdAt on re-login
      await updateDoc(userRef, {
        lastLoginAt: serverTimestamp(),
        provider,
        // Update displayName/photoURL in case they changed in their SSO account
        ...(firebaseUser.displayName  ? { displayName: firebaseUser.displayName }  : {}),
        ...(firebaseUser.photoURL     ? { photoURL:     firebaseUser.photoURL }     : {}),
      });
    }
  },

  async _createUserDocument(firebaseUser, provider, role) {
    await setDoc(doc(db, 'users', firebaseUser.uid), {
      email:                  firebaseUser.email,
      displayName:            firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'Kivora User',
      photoURL:               firebaseUser.photoURL || null,
      role,                   // 'parent' | 'teacher'
      provider,               // 'google' | 'apple' | 'microsoft' | 'email'
      plan:                   'free',                // NEVER changed from client — Cloud Function or backend only
      curriculumPreference:   'international',       // 'common-core' | 'uk-national' | 'international'
      weeklyReportEnabled:    true,
      weeklyReportDay:        'sunday',
      timezone:               Intl.DateTimeFormat().resolvedOptions().timeZone,
      createdAt:              serverTimestamp(),
      lastLoginAt:            serverTimestamp(),
    });
  },
};


// ═══════════════════════════════════════════════════════════════════════
// USER SERVICE
// Reads and updates the /users/{uid} document (parent/teacher account).
// ═══════════════════════════════════════════════════════════════════════

export const UserService = {

  async getUser(uid) {
    const snap = await getDoc(doc(db, 'users', uid));
    return snap.exists() ? { uid: snap.id, ...snap.data() } : null;
  },

  /**
   * Update user-controlled settings. Allowlisted — client cannot change
   * plan, role, or timestamps.
   */
  async updateSettings(uid, settings) {
    const ALLOWED = ['curriculumPreference', 'weeklyReportEnabled', 'weeklyReportDay', 'timezone', 'displayName', 'photoURL'];
    const safe = Object.fromEntries(Object.entries(settings).filter(([k]) => ALLOWED.includes(k)));
    if (Object.keys(safe).length === 0) return;
    await updateDoc(doc(db, 'users', uid), safe);
  },

  /** Real-time listener — drives dashboard header with live plan/name data. */
  subscribeToUser(uid, callback) {
    return onSnapshot(doc(db, 'users', uid), snap => {
      callback(snap.exists() ? { uid: snap.id, ...snap.data() } : null);
    });
  },
};


// ═══════════════════════════════════════════════════════════════════════
// CHILD SERVICE
// Manages child profiles under /users/{parentUid}/children/{childId}.
// COPPA note: stores display name only. No surname, no birthdate, no email.
// ═══════════════════════════════════════════════════════════════════════

export const ChildService = {

  /**
   * Create a child profile.
   * childData: { name, ageGroup, avatar?, curriculumPreference?, bedtimeLock?, screenTimeDailyLimitMinutes? }
   * ageGroup: 'toddler' | 'pre-k' | 'kindergarten' | 'grade-1' .. 'grade-5'
   */
  async addChild(parentUid, childData) {
    const ref = doc(collection(db, 'users', parentUid, 'children'));
    const profile = {
      // Identity (COPPA minimized)
      name:                         childData.name,
      ageGroup:                     childData.ageGroup,
      avatar:                       childData.avatar || '🦊',
      curriculumPreference:         childData.curriculumPreference || 'international',

      // Parental controls
      bedtimeLock:                  childData.bedtimeLock || '20:00',
      screenTimeDailyLimitMinutes:  childData.screenTimeDailyLimitMinutes || 0, // 0 = no limit

      // Aggregate reward counters  ← ONLY increment() from here on, never set directly
      totalXP:                      0,
      totalCoins:                   0,
      totalGems:                    0,
      totalStars:                   0,
      activitiesCompleted:          0,
      badgeCount:                   0,
      certificateCount:             0,

      // Screen-time state (Cloud Function resets screenTimeToday at midnight)
      screenTimeToday:              0,
      screenTimeTodayDate:          new Date().toISOString().split('T')[0],

      lastActiveAt:                 serverTimestamp(),
      createdAt:                    serverTimestamp(),
    };
    await setDoc(ref, profile);
    return { childId: ref.id, ...profile };
  },

  async getChildren(parentUid) {
    const q    = query(collection(db, 'users', parentUid, 'children'), orderBy('createdAt', 'asc'));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ childId: d.id, ...d.data() }));
  },

  async getChild(parentUid, childId) {
    const snap = await getDoc(doc(db, 'users', parentUid, 'children', childId));
    return snap.exists() ? { childId: snap.id, ...snap.data() } : null;
  },

  /**
   * Update editable child settings. Aggregate counters are NOT in this allowlist —
   * they can only be modified via increment() in ProgressService.
   */
  async updateChild(parentUid, childId, updates) {
    const ALLOWED = ['name', 'avatar', 'curriculumPreference', 'bedtimeLock', 'screenTimeDailyLimitMinutes', 'ageGroup'];
    const safe    = Object.fromEntries(Object.entries(updates).filter(([k]) => ALLOWED.includes(k)));
    if (Object.keys(safe).length === 0) return;
    await updateDoc(doc(db, 'users', parentUid, 'children', childId), safe);
  },

  /**
   * Soft-delete child profile document.
   * NOTE: Firestore does NOT cascade-delete subcollections.
   * Trigger the 'deleteChildData' Cloud Function for full GDPR erasure.
   */
  async deleteChild(parentUid, childId) {
    await deleteDoc(doc(db, 'users', parentUid, 'children', childId));
    // TODO: call deleteChildData Cloud Function here for full data erasure
  },

  subscribeToChildren(parentUid, callback) {
    const q = query(collection(db, 'users', parentUid, 'children'), orderBy('createdAt', 'asc'));
    return onSnapshot(q, snap => callback(snap.docs.map(d => ({ childId: d.id, ...d.data() }))));
  },
};


// ═══════════════════════════════════════════════════════════════════════
// PROGRESS SERVICE
// Handles activity completion — the most critical write path.
//
// On saveActivityProgress:
//   1. Creates activityProgress/{actCode} doc (idempotent — won't double-reward)
//   2. Atomically increments child aggregate counters
//   3. Updates daily session doc (screen time + daily XP)
//   Cloud Function 'onActivityCompleted' then fires server-side to:
//   - Rebuild worldProgress summary
//   - Run badge engine
//   - Sync teacher roster summary
//   - Cross-validate XP against master activity plan (anti-cheat)
// ═══════════════════════════════════════════════════════════════════════

export const ProgressService = {

  /**
   * Save a completed activity. Call this from the reward overlay.
   *
   * @param {string}  parentUid
   * @param {string}  childId
   * @param {object}  actData         — activity record from ACTS array
   *                  { code, world, title, type, grade, difficulty, xp, coins }
   * @param {object}  result
   *                  { wrongAttempts, perfectBonus, completedInMs }
   * @returns {object} { success, alreadyCompleted, xpEarned, coinsEarned, gemsEarned }
   */
  async saveActivityProgress(parentUid, childId, actData, result = {}) {
    const progressRef = doc(db, 'users', parentUid, 'children', childId, 'activityProgress', actData.code);

    // ── Idempotency guard ─────────────────────────────────────────────
    const existing = await getDoc(progressRef);
    if (existing.exists()) return { alreadyCompleted: true, success: false };

    // ── Validate rewards against difficulty table ──────────────────────
    // This is a client-side pre-check. Cloud Function re-validates server-side.
    const expectedRewards = DIFFICULTY_REWARDS[actData.difficulty] || DIFFICULTY_REWARDS['easy'];
    const xpEarned     = expectedRewards.xp     + (result.perfectBonus ? PERFECT_BONUS.xp    : 0);
    const coinsEarned  = expectedRewards.coins   + (result.perfectBonus ? PERFECT_BONUS.coins : 0);
    const gemsEarned   = expectedRewards.gems    || 0;

    const today = new Date().toISOString().split('T')[0];

    // ── Batch write: 3 docs in one atomic commit ───────────────────────
    const batch = writeBatch(db);

    // 1. Activity progress document (write-once — security rule prevents updates)
    batch.set(progressRef, {
      worldSlug:       actData.world,
      title:           actData.title,
      activityType:    actData.type,
      grade:           actData.grade        || 'unknown',
      difficulty:      actData.difficulty   || 'easy',
      xpEarned,
      coinsEarned,
      gemsEarned,
      wrongAttempts:   result.wrongAttempts || 0,
      perfectBonus:    result.perfectBonus  || false,
      completedInMs:   result.completedInMs || null,
      completedAt:     serverTimestamp(),
    });

    // 2. Child aggregate counters — atomic increments prevent race conditions
    batch.update(doc(db, 'users', parentUid, 'children', childId), {
      totalXP:              increment(xpEarned),
      totalCoins:           increment(coinsEarned),
      totalGems:            increment(gemsEarned),
      totalStars:           increment(1),
      activitiesCompleted:  increment(1),
      lastActiveAt:         serverTimestamp(),
    });

    // 3. Daily session doc — merge:true creates it on first activity of the day
    batch.set(
      doc(db, 'users', parentUid, 'children', childId, 'dailySessions', today),
      {
        date:                 today,
        activitiesCompleted:  increment(1),
        xpEarned:             increment(xpEarned),
        coinsEarned:          increment(coinsEarned),
        lastActive:           serverTimestamp(),
      },
      { merge: true }
    );

    await batch.commit();
    return { success: true, xpEarned, coinsEarned, gemsEarned };
  },

  /**
   * Check if a single activity is done — used before launching an activity.
   */
  async isActivityCompleted(parentUid, childId, actCode) {
    const snap = await getDoc(doc(db, 'users', parentUid, 'children', childId, 'activityProgress', actCode));
    return snap.exists();
  },

  /**
   * Get all completed activity codes for a world.
   * Returns a Set for O(1) grid-rendering lookups.
   */
  async getWorldCompletedCodes(parentUid, childId, worldSlug) {
    const q    = query(
      collection(db, 'users', parentUid, 'children', childId, 'activityProgress'),
      where('worldSlug', '==', worldSlug),
    );
    const snap = await getDocs(q);
    return new Set(snap.docs.map(d => d.id));
  },

  /**
   * Get ALL completed codes across all worlds.
   * Use for the full activity library view.
   */
  async getAllCompletedCodes(parentUid, childId) {
    const snap = await getDocs(collection(db, 'users', parentUid, 'children', childId, 'activityProgress'));
    return new Set(snap.docs.map(d => d.id));
  },

  /**
   * Get world progress summary (maintained by Cloud Function).
   * Falls back to zeros if the Cloud Function hasn't run yet.
   */
  async getWorldProgress(parentUid, childId, worldSlug) {
    const snap = await getDoc(doc(db, 'users', parentUid, 'children', childId, 'worldProgress', worldSlug));
    return snap.exists() ? snap.data() : {
      worldSlug,
      activitiesCompleted: 0,
      activitiesTotal:     WORLD_ACTIVITY_TOTALS[worldSlug] || 0,
      percentComplete:     0,
      xpEarned:            0,
      certificateEarned:   false,
    };
  },

  /**
   * Get all 9 world progress summaries in a single batch.
   * Used for the parent dashboard world-breakdown grid.
   */
  async getAllWorldProgress(parentUid, childId) {
    const snap   = await getDocs(collection(db, 'users', parentUid, 'children', childId, 'worldProgress'));
    const result = {};
    snap.docs.forEach(d => { result[d.id] = d.data(); });
    // Fill missing worlds with zero baseline
    WORLDS.forEach(w => {
      if (!result[w]) result[w] = {
        worldSlug:            w,
        activitiesCompleted:  0,
        activitiesTotal:      WORLD_ACTIVITY_TOTALS[w],
        percentComplete:      0,
        xpEarned:             0,
        certificateEarned:    false,
      };
    });
    return result;
  },

  /**
   * Recent activity for the "Continue Learning" section.
   * Returns last N completed activities, newest first.
   */
  async getRecentActivity(parentUid, childId, count = 5) {
    const q    = query(
      collection(db, 'users', parentUid, 'children', childId, 'activityProgress'),
      orderBy('completedAt', 'desc'),
      limit(count),
    );
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ code: d.id, ...d.data() }));
  },

  /** Real-time world progress for the live progress bar in the activity player. */
  subscribeToWorldProgress(parentUid, childId, worldSlug, callback) {
    return onSnapshot(
      doc(db, 'users', parentUid, 'children', childId, 'worldProgress', worldSlug),
      snap => callback(snap.exists() ? snap.data() : null)
    );
  },

  /** Real-time child totals for the live XP/coin counter in the child dashboard. */
  subscribeToChildTotals(parentUid, childId, callback) {
    return onSnapshot(
      doc(db, 'users', parentUid, 'children', childId),
      snap => callback(snap.exists() ? snap.data() : null)
    );
  },
};


// ═══════════════════════════════════════════════════════════════════════
// SCREEN TIME SERVICE
// Tracks session minutes and enforces parental controls.
// ═══════════════════════════════════════════════════════════════════════

export const ScreenTimeService = {

  /**
   * Call on page load / child dashboard open.
   * Returns { allowed, reason, bedtimeLock, limitMinutes, minutesUsedToday }
   */
  async startSession(parentUid, childId) {
    const childSnap = await getDoc(doc(db, 'users', parentUid, 'children', childId));
    if (!childSnap.exists()) return { allowed: false, reason: 'child_not_found' };

    const child = childSnap.data();
    const today  = new Date().toISOString().split('T')[0];
    const now    = new Date();

    // ── Bedtime lock ──────────────────────────────────────────────────
    const [lockH, lockM] = (child.bedtimeLock || '20:00').split(':').map(Number);
    const lockMinutes    = lockH * 60 + lockM;
    const nowMinutes     = now.getHours() * 60 + now.getMinutes();
    if (nowMinutes >= lockMinutes) {
      return { allowed: false, reason: 'bedtime_lock', bedtimeLock: child.bedtimeLock };
    }

    // ── Daily screen time limit ───────────────────────────────────────
    if (child.screenTimeDailyLimitMinutes > 0) {
      let minutesUsed = child.screenTimeToday || 0;
      // If stored date is stale, reset the counter
      if (child.screenTimeTodayDate !== today) {
        minutesUsed = 0;
        await updateDoc(doc(db, 'users', parentUid, 'children', childId), {
          screenTimeToday:     0,
          screenTimeTodayDate: today,
        });
      }
      if (minutesUsed >= child.screenTimeDailyLimitMinutes) {
        return {
          allowed:       false,
          reason:        'daily_limit_reached',
          minutesUsed,
          limitMinutes:  child.screenTimeDailyLimitMinutes,
        };
      }
      return {
        allowed:       true,
        minutesUsed,
        limitMinutes:  child.screenTimeDailyLimitMinutes,
        bedtimeLock:   child.bedtimeLock,
      };
    }

    // Record session start in daily doc
    await setDoc(
      doc(db, 'users', parentUid, 'children', childId, 'dailySessions', today),
      { date: today, sessionStartedAt: serverTimestamp(), lastActive: serverTimestamp() },
      { merge: true }
    );

    // Store session start time on window for endSession reference
    window._kivoraSessionStart    = Date.now();
    window._kivoraActiveChildId   = childId;
    window._kivoraActiveParentUid = parentUid;

    return { allowed: true, limitMinutes: 0, bedtimeLock: child.bedtimeLock };
  },

  /**
   * Call on page unload. Uses a low-latency path.
   * For unload reliability, consider pairing with navigator.sendBeacon
   * to a Cloud Function endpoint for the final session write.
   */
  async endSession(parentUid, childId, sessionStartMs) {
    const elapsedMinutes = Math.round((Date.now() - sessionStartMs) / 60000);
    if (elapsedMinutes < 1) return; // Ignore < 1-minute sessions

    const today = new Date().toISOString().split('T')[0];
    const batch = writeBatch(db);

    batch.set(
      doc(db, 'users', parentUid, 'children', childId, 'dailySessions', today),
      { totalMinutes: increment(elapsedMinutes), lastActive: serverTimestamp() },
      { merge: true }
    );

    batch.update(doc(db, 'users', parentUid, 'children', childId), {
      screenTimeToday:     increment(elapsedMinutes),
      screenTimeTodayDate: today,
      lastActiveAt:        serverTimestamp(),
    });

    await batch.commit();
  },

  /**
   * Last 7 days of screen time data for the parent dashboard graph.
   * Returns { [YYYY-MM-DD]: { totalMinutes, activitiesCompleted, xpEarned } }
   */
  async getWeeklyScreenTime(parentUid, childId) {
    const results = {};
    const today   = new Date();
    for (let i = 6; i >= 0; i--) {
      const d       = new Date(today);
      d.setDate(today.getDate() - i);
      const dateKey = d.toISOString().split('T')[0];
      const snap    = await getDoc(
        doc(db, 'users', parentUid, 'children', childId, 'dailySessions', dateKey)
      );
      results[dateKey] = snap.exists()
        ? snap.data()
        : { totalMinutes: 0, activitiesCompleted: 0, xpEarned: 0 };
    }
    return results;
  },
};


// ═══════════════════════════════════════════════════════════════════════
// BADGE SERVICE
// Badge awarding is SERVER-SIDE ONLY (Cloud Function: badge engine).
// Client: read badges, subscribe to new ones for real-time toast notifications.
// ═══════════════════════════════════════════════════════════════════════

export const BadgeService = {

  async getBadges(parentUid, childId) {
    const q    = query(
      collection(db, 'users', parentUid, 'children', childId, 'badges'),
      orderBy('earnedAt', 'desc'),
    );
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ badgeId: d.id, ...d.data() }));
  },

  /**
   * Subscribe to new badge events. Fires the callback with the new badge
   * data whenever the Cloud Function awards one. Use to show a toast/modal.
   */
  subscribeToNewBadges(parentUid, childId, onNewBadge) {
    const q    = query(
      collection(db, 'users', parentUid, 'children', childId, 'badges'),
      orderBy('earnedAt', 'desc'),
      limit(1),
    );
    let initialized = false;
    return onSnapshot(q, snap => {
      if (!initialized) { initialized = true; return; }
      if (!snap.empty) onNewBadge({ badgeId: snap.docs[0].id, ...snap.docs[0].data() });
    });
  },
};


// ═══════════════════════════════════════════════════════════════════════
// PATH PROGRESS SERVICE
// Tracks progress through the 24 Learning Paths.
// ═══════════════════════════════════════════════════════════════════════

export const PathService = {

  async startPath(parentUid, childId, pathCode, pathTitle, activitiesTotal) {
    const ref = doc(db, 'users', parentUid, 'children', childId, 'pathProgress', pathCode);
    await setDoc(ref, {
      pathCode, pathTitle, activitiesTotal,
      status:               'in_progress',
      activitiesCompleted:  0,
      percentComplete:      0,
      startedAt:            serverTimestamp(),
      completedAt:          null,
    }, { merge: true }); // merge so re-starting doesn't wipe progress
  },

  async updatePathProgress(parentUid, childId, pathCode, activitiesCompleted, activitiesTotal) {
    const percentComplete = Math.round((activitiesCompleted / activitiesTotal) * 100);
    const isComplete      = activitiesCompleted >= activitiesTotal;
    await updateDoc(doc(db, 'users', parentUid, 'children', childId, 'pathProgress', pathCode), {
      activitiesCompleted,
      percentComplete,
      status:      isComplete ? 'completed' : 'in_progress',
      completedAt: isComplete ? serverTimestamp() : null,
    });
  },

  async getPathProgress(parentUid, childId) {
    const snap = await getDocs(
      collection(db, 'users', parentUid, 'children', childId, 'pathProgress')
    );
    return snap.docs.map(d => ({ pathCode: d.id, ...d.data() }));
  },
};


// ═══════════════════════════════════════════════════════════════════════
// DASHBOARD SERVICE
// Assembles data payloads for each dashboard view.
// Uses Promise.all for parallel reads — minimises total latency.
// ═══════════════════════════════════════════════════════════════════════

export const DashboardService = {

  /**
   * Child dashboard: 3 parallel reads → full payload in ~1 round-trip.
   * Returns data for: rewards header, continue-learning section, badges row.
   */
  async getChildDashboardData(parentUid, childId) {
    const [childSnap, recentActivity, badges] = await Promise.all([
      getDoc(doc(db, 'users', parentUid, 'children', childId)),
      ProgressService.getRecentActivity(parentUid, childId, 5),
      BadgeService.getBadges(parentUid, childId),
    ]);

    if (!childSnap.exists()) throw new Error('Child profile not found');

    const childData  = childSnap.data();
    const levelData  = calcLevelData(childData.totalXP);

    return {
      child: {
        childId,
        ...childData,
        ...levelData,
      },
      recentActivity,
      badges:         badges.slice(0, 6),
    };
  },

  /**
   * Parent dashboard: loads all children with world progress and screen time.
   * N children × 2 parallel reads each (worldProgress + screenTime).
   */
  async getParentDashboardData(parentUid) {
    const children = await ChildService.getChildren(parentUid);

    const childrenWithProgress = await Promise.all(
      children.map(async child => {
        const [worldProgress, weeklyScreenTime] = await Promise.all([
          ProgressService.getAllWorldProgress(parentUid, child.childId),
          ScreenTimeService.getWeeklyScreenTime(parentUid, child.childId),
        ]);
        return {
          ...child,
          ...calcLevelData(child.totalXP),
          worldProgress,
          weeklyScreenTime,
        };
      })
    );

    return { children: childrenWithProgress };
  },

  /**
   * Teacher dashboard: single roster query (no N+1).
   * Roster docs hold denormalized student summaries, updated by Cloud Function.
   */
  async getTeacherDashboardData(teacherUid) {
    const classes = await ClassService.getTeacherClasses(teacherUid);

    const classesWithRosters = await Promise.all(
      classes.map(async cls => {
        const roster = await ClassService.getClassRoster(cls.classId);
        return { ...cls, roster };
      })
    );

    return { classes: classesWithRosters };
  },
};


// ═══════════════════════════════════════════════════════════════════════
// CLASS SERVICE (Teachers)
// Manages teacher classes, student enrollment (with COPPA consent),
// and activity assignments.
// COPPA / GDPR-K: teacher sees only childDisplayName (no surname),
// and only after parent has granted consent via enrollment.
// ═══════════════════════════════════════════════════════════════════════

export const ClassService = {

  async createClass(teacherUid, classData) {
    const ref = doc(collection(db, 'classes'));
    await setDoc(ref, {
      teacherUid,
      name:               classData.name,
      grade:              classData.grade,
      curriculumStandard: classData.curriculumStandard || 'international',
      schoolName:         classData.schoolName   || null,
      schoolCountry:      classData.schoolCountry || null,
      studentCount:       0,
      createdAt:          serverTimestamp(),
    });
    return ref.id;
  },

  /**
   * Enroll a child in a class.
   * MUST be called by the parent — their uid becomes consentGivenBy.
   * In production: teacher generates a class code → parent enters code to enroll.
   */
  async enrollStudent(classId, parentUid, childId, childDisplayName, grade) {
    const rosterRef = doc(collection(db, 'classes', classId, 'roster'));
    const batch     = writeBatch(db);

    batch.set(rosterRef, {
      parentUid,
      childId,
      childDisplayName,       // Display name only — no surname (COPPA)
      grade,
      enrolledAt:             serverTimestamp(),
      consentGivenAt:         serverTimestamp(), // Consent recorded at enrollment
      consentGivenBy:         parentUid,         // Parent triggered this action
      isActive:               true,

      // Denormalized student summary (Cloud Function keeps these in sync)
      totalXP:                0,
      totalCoins:             0,
      activitiesCompleted:    0,
      lastActiveAt:           null,
      worldProgress:          {},
      level:                  1,
      badgeCount:             0,
    });

    batch.update(doc(db, 'classes', classId), { studentCount: increment(1) });

    await batch.commit();
    return rosterRef.id;
  },

  /**
   * Get roster with denormalized summaries — ONE collection query.
   * Default order: leaderboard (totalXP desc).
   */
  async getClassRoster(classId, sortBy = 'totalXP') {
    const q    = query(
      collection(db, 'classes', classId, 'roster'),
      where('isActive', '==', true),
      orderBy(sortBy, 'desc'),
    );
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ rosterId: d.id, ...d.data() }));
  },

  async getTeacherClasses(teacherUid) {
    const q    = query(
      collection(db, 'classes'),
      where('teacherUid', '==', teacherUid),
      orderBy('createdAt', 'desc'),
    );
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ classId: d.id, ...d.data() }));
  },

  async createAssignment(classId, teacherUid, assignmentData) {
    const ref = doc(collection(db, 'classes', classId, 'assignments'));
    await setDoc(ref, {
      teacherUid,
      type:         assignmentData.type,        // 'activity' | 'path' | 'collection'
      referenceId:  assignmentData.referenceId,
      title:        assignmentData.title,
      notes:        assignmentData.notes  || null,
      assignedTo:   assignmentData.assignedTo || 'all', // 'all' or array of rosterIds
      assignedAt:   serverTimestamp(),
      dueAt:        assignmentData.dueAt ? Timestamp.fromDate(new Date(assignmentData.dueAt)) : null,
    });
    return ref.id;
  },

  /** Real-time roster for live leaderboard on teacher dashboard. */
  subscribeToClassRoster(classId, callback, sortBy = 'totalXP') {
    const q = query(
      collection(db, 'classes', classId, 'roster'),
      where('isActive', '==', true),
      orderBy(sortBy, 'desc'),
    );
    return onSnapshot(q, snap => callback(snap.docs.map(d => ({ rosterId: d.id, ...d.data() }))));
  },
};


// ═══════════════════════════════════════════════════════════════════════
// MIGRATION SERVICE
// One-time migration from localStorage to Firestore.
// Call after first login for any user that has localStorage data.
// ═══════════════════════════════════════════════════════════════════════

export const MigrationService = {

  /**
   * Migrate localStorage progress to Firestore.
   * @param {string}   parentUid
   * @param {string}   childId        — child profile to assign progress to
   * @param {object[]} ACTS            — full ACTS array from activity player
   * @returns {{ migrated: number, totalXP: number, totalCoins: number }}
   */
  async migrateFromLocalStorage(parentUid, childId, ACTS) {
    let raw = {};
    try { raw = JSON.parse(localStorage.getItem('kivora_progress') || '{}'); } catch { return { migrated: 0 }; }

    const completedCodes = Object.keys(raw).filter(k => raw[k] === true);
    if (completedCodes.length === 0) return { migrated: 0 };

    // Don't double-migrate activities already in Firestore
    const alreadyDone = await ProgressService.getAllCompletedCodes(parentUid, childId);
    const toMigrate   = completedCodes.filter(c => !alreadyDone.has(c));
    if (toMigrate.length === 0) {
      localStorage.removeItem('kivora_progress');
      return { migrated: 0 };
    }

    const actMap = new Map(ACTS.map(a => [a.code, a]));
    let totalXP = 0, totalCoins = 0, migratedCount = 0;

    // Firestore batch limit is 500 ops — chunk accordingly
    for (let i = 0; i < toMigrate.length; i += 400) {
      const chunk = toMigrate.slice(i, i + 400);
      const batch = writeBatch(db);

      for (const code of chunk) {
        const act = actMap.get(code);
        if (!act) continue;

        const rewards = DIFFICULTY_REWARDS[act.difficulty] || DIFFICULTY_REWARDS['easy'];
        const ref     = doc(db, 'users', parentUid, 'children', childId, 'activityProgress', code);

        batch.set(ref, {
          worldSlug:               act.world,
          title:                   act.title,
          activityType:            act.type,
          grade:                   act.grade      || 'unknown',
          difficulty:              act.difficulty || 'easy',
          xpEarned:                rewards.xp,
          coinsEarned:             rewards.coins,
          gemsEarned:              0,
          wrongAttempts:           0,
          perfectBonus:            false,
          completedInMs:           null,
          completedAt:             serverTimestamp(),
          migratedFromLocalStorage: true,
        });

        totalXP    += rewards.xp;
        totalCoins += rewards.coins;
        migratedCount++;
      }

      await batch.commit();
    }

    // Single aggregate update for all migrated activities
    if (migratedCount > 0) {
      await updateDoc(doc(db, 'users', parentUid, 'children', childId), {
        totalXP:             increment(totalXP),
        totalCoins:          increment(totalCoins),
        totalStars:          increment(migratedCount),
        activitiesCompleted: increment(migratedCount),
      });
    }

    // Clear localStorage after successful migration
    localStorage.removeItem('kivora_progress');
    localStorage.removeItem('kivora_user');

    return { migrated: migratedCount, totalXP, totalCoins };
  },
};


// ═══════════════════════════════════════════════════════════════════════
// SESSION LIFECYCLE HOOKS
// Wire these to window events in your app entry point (index.html).
//
// Usage:
//   import { initSessionLifecycle } from './firebase-service.js';
//   initSessionLifecycle();
// ═══════════════════════════════════════════════════════════════════════

export function initSessionLifecycle() {
  window.addEventListener('beforeunload', () => {
    const uid     = window._kivoraActiveParentUid;
    const childId = window._kivoraActiveChildId;
    const start   = window._kivoraSessionStart;
    if (uid && childId && start) {
      // Synchronous Firestore writes may not complete on unload.
      // Use navigator.sendBeacon to a Cloud Function for reliability in production.
      ScreenTimeService.endSession(uid, childId, start).catch(() => {});
    }
  });

  // Pause timer when tab is hidden, resume when visible
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      window._kivoraPausedAt = Date.now();
    } else if (window._kivoraSessionStart && window._kivoraPausedAt) {
      // Shift the start time forward by the hidden duration so paused time isn't counted
      window._kivoraSessionStart += (Date.now() - window._kivoraPausedAt);
      window._kivoraPausedAt = null;
    }
  });
}
