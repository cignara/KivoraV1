/**
 * Kivora Learning — Firebase Configuration
 * firebase-config.js  v1.0
 *
 * Replace the FIREBASE_CONFIG values with your project credentials from
 * Firebase Console → Project Settings → Your Apps → Web App.
 *
 * Firebase SDK: v10 modular (tree-shakeable). Do NOT use the compat bundle.
 * CDN: https://www.gstatic.com/firebasejs/10.12.0/
 */

import { initializeApp }               from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js';
import { getAuth }                      from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';
import {
  getFirestore,
  enableIndexedDbPersistence,
  CACHE_SIZE_UNLIMITED,
  initializeFirestore,
}                                       from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';

// ─────────────────────────────────────────────────────────────
// PROJECT CREDENTIALS  ·  Replace before deploying
// ─────────────────────────────────────────────────────────────
const FIREBASE_CONFIG = {
  apiKey:            'YOUR_API_KEY',
  authDomain:        'kivora-learning.firebaseapp.com',
  projectId:         'kivora-learning',
  storageBucket:     'kivora-learning.appspot.com',
  messagingSenderId: 'YOUR_SENDER_ID',
  appId:             'YOUR_APP_ID',
  measurementId:     'YOUR_MEASUREMENT_ID',
};

// ─────────────────────────────────────────────────────────────
// APP INIT
// ─────────────────────────────────────────────────────────────
// ── Guest / unconfigured mode ──────────────────────────────────────────
// If FIREBASE_CONFIG still has placeholder values, Firebase throws on init.
// We catch this so the rest of the site (activity player, localStorage
// progress, UI) keeps working in guest mode without any login.
const _credsSet = FIREBASE_CONFIG.apiKey && FIREBASE_CONFIG.apiKey !== 'YOUR_API_KEY';

let app, auth, db;
if (_credsSet) {
  try {
    app  = initializeApp(FIREBASE_CONFIG);
    auth = getAuth(app);
    db   = initializeFirestore(app, { cacheSizeBytes: CACHE_SIZE_UNLIMITED });
  } catch (e) {
    console.warn('[Kivora] Firebase init failed — guest mode active:', e.message);
    auth = null; db = null;
  }
} else {
  console.info('[Kivora] Firebase credentials not set — running in guest/demo mode. Add real credentials to firebase-config.js to enable accounts.');
  auth = null; db = null;
}
export { auth, db };

// ─────────────────────────────────────────────────────────────
// OFFLINE PERSISTENCE
// Enables Firestore to serve cached data when the device is
// offline (essential for mobile users on spotty connections).
// COPPA note: IndexedDB only caches data the authenticated user
// is already authorised to see — no privacy regression.
// ─────────────────────────────────────────────────────────────
if (db) enableIndexedDbPersistence(db).catch(err => {
  if (err.code === 'failed-precondition') {
    // Multiple tabs open; persistence available only in one.
    console.warn('[Kivora] Offline persistence disabled — multiple tabs detected.');
  } else if (err.code === 'unimplemented') {
    // Browser doesn't support IndexedDB.
    console.warn('[Kivora] Offline persistence not supported in this browser.');
  }
});

// ─────────────────────────────────────────────────────────────
// ENVIRONMENT CHECK
// ─────────────────────────────────────────────────────────────
export const isDev = location.hostname === 'localhost' || location.hostname === '127.0.0.1';

if (isDev) {
  console.info('[Kivora Firebase] Running in development mode.');
  // Uncomment to use local emulators:
  // import { connectAuthEmulator }      from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js';
  // import { connectFirestoreEmulator } from 'https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js';
  // connectAuthEmulator(auth, 'http://localhost:9099');
  // connectFirestoreEmulator(db, 'localhost', 8080);
}
