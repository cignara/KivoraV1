# Kivora Learning — Deployment Setup
## Version 1.0 · June 2026

---

## STEP 1 · Get your Firebase credentials (3 minutes)

1. Go to https://console.firebase.google.com
2. Click **Add project** → name it `kivora-learning` → Continue → Create project
3. On the project homepage, click the **</>** (Web) icon
4. Register app name: `Kivora Web` → click **Register app**
5. Copy the `firebaseConfig` object shown — you'll need it in Step 3

---

## STEP 2 · Enable authentication providers (2 minutes)

In Firebase Console:

1. Left menu → **Authentication** → **Get started**
2. **Sign-in method** tab → enable these three:
   - **Google** → enable → save
   - **Apple** → enable → enter your Apple Service ID + key (from developer.apple.com) → save
   - **Microsoft** → enable → enter your Azure AD App ID + secret → save
3. **Settings** tab → **Authorised domains** → your live domain will be added automatically after deploy

---

## STEP 3 · Paste your credentials (1 minute)

Open `public/firebase-config.js` and replace the placeholder block:

```javascript
const FIREBASE_CONFIG = {
  apiKey:            'PASTE_YOUR_API_KEY_HERE',
  authDomain:        'YOUR_PROJECT_ID.firebaseapp.com',
  projectId:         'YOUR_PROJECT_ID',
  storageBucket:     'YOUR_PROJECT_ID.appspot.com',
  messagingSenderId: 'YOUR_SENDER_ID',
  appId:             'YOUR_APP_ID',
  measurementId:     'YOUR_MEASUREMENT_ID',
};
```

All values come from the config object copied in Step 1.

---

## STEP 4 · Install Firebase CLI and deploy (3 minutes)

```bash
# Install CLI (once)
npm install -g firebase-tools

# Log in with your Google account
firebase login

# Navigate to this folder
cd kivora-deploy

# Deploy everything (hosting + Firestore rules + indexes)
firebase deploy
```

Firebase will print:

```
✔  Deploy complete!
✔  Hosting URL: https://kivora-learning.web.app
```

**That is your live URL.**

---

## STEP 5 · Test the live site

1. Open `https://kivora-learning.web.app`
2. Click **Start Free** → complete the 3-step registration
3. Sign in with Google to confirm SSO works
4. Complete one activity → confirm XP appears in the child dashboard
5. Open the parent dashboard → confirm the activity shows in Recent Activity

---

## File structure (what's in this folder)

```
kivora-deploy/
├── firebase.json              ← Hosting + Firestore config (do not edit)
├── .firebaserc                ← Project alias (update project ID if needed)
├── firestore.rules            ← Security rules (deployed automatically)
├── firestore.indexes.json     ← Composite indexes (deployed automatically)
├── firebase-functions-spec.md ← Cloud Functions spec (implement separately)
└── public/                    ← Everything in here is served to the browser
    ├── index.html
    ├── firebase-config.js     ← ← ← ADD YOUR CREDENTIALS HERE
    ├── firebase-service.js
    ├── kivora-activity-player.html
    └── activity-AI-T-001-v4.html
```

---

## Common issues

| Problem | Fix |
|---|---|
| Auth buttons do nothing | `firebase-config.js` still has placeholder values |
| "auth/unauthorized-domain" error | Add your domain in Firebase Console → Auth → Settings → Authorised domains |
| Module import errors in console | You opened `index.html` from the file system — must be served over HTTP |
| Firestore permission denied | Run `firebase deploy --only firestore:rules` to push the security rules |
| Apple / Microsoft login not working | Requires additional configuration in Apple Developer / Azure AD portals |

---

*Kivora Learning · Firebase Deployment Package v1.0*
