# Kivora Learning — Cloud Functions Specification
## firebase-functions-spec.md  v1.0

Cloud Functions are the server-side authority layer. They handle work that cannot
safely be done on the client: aggregate rebuilding, badge logic, anti-cheat validation,
GDPR erasure, and weekly report generation.

All functions are Node.js 20 (LTS), Firebase Functions v2.

---

## Function Index

| Function | Trigger | Purpose |
|---|---|---|
| `onActivityCompleted` | Firestore write | Rebuild worldProgress, badge engine, roster sync, anti-cheat |
| `onChildDeleted` | Firestore delete | Cascade-delete all subcollections (GDPR Art. 17) |
| `resetScreenTimeDaily` | Cron 00:01 daily | Reset screenTimeToday counter for all children |
| `sendWeeklyReports` | Cron Sunday 08:00 | Email parent progress reports |
| `syncRosterOnProgress` | Firestore write | Update teacher roster summary when child completes activity |
| `onEnrollmentCreated` | Firestore write | Send teacher notification when parent enrolls a child |
| `updatePlanOnPayment` | HTTPS (Stripe webhook) | Upgrade/downgrade user plan in Firestore |
| `deleteChildData` | HTTPS (callable) | Full GDPR data erasure for a child profile + all subcollections |
| `endSessionBeacon` | HTTPS (callable) | Receives navigator.sendBeacon on page unload for session end |

---

## 1. `onActivityCompleted`

**Trigger:** `onDocumentCreated('users/{uid}/children/{childId}/activityProgress/{actCode}')`

**Responsibilities:**

### 1a. Anti-cheat validation
Cross-references the written xpEarned/coinsEarned against the master activity table.
If values don't match, reverses the increment on the child doc and logs a security alert.

```javascript
const MASTER_ACTIVITIES = require('./data/activities-master.json'); // generated from Master Activity Plan v4
const actRecord = MASTER_ACTIVITIES[actCode];
if (!actRecord) {
  // Unknown activity code — reject write
  await admin.firestore()
    .doc(`users/${uid}/children/${childId}`)
    .update({ totalXP: FieldValue.increment(-data.xpEarned), ... });
  return;
}
const expectedXP = actRecord.xp + (data.perfectBonus ? 10 : 0);
if (data.xpEarned !== expectedXP) {
  // Mismatch — reverse and log
  ...
}
```

### 1b. World progress rebuild
After validating, rebuild the worldProgress summary for the affected world:
```javascript
const worldActivities = MASTER_ACTIVITIES filter by worldSlug;
const completedSnap   = await getDocs(query(activityProgressRef, where('worldSlug', '==', worldSlug)));
const completedCount  = completedSnap.size;
const total           = worldActivities.length;
const percent         = Math.round((completedCount / total) * 100);

await worldProgressRef.set({
  worldSlug, activitiesCompleted: completedCount, activitiesTotal: total,
  percentComplete: percent,
  xpEarned: completedSnap.docs.reduce((sum, d) => sum + d.data().xpEarned, 0),
  certificateEarned: percent === 100,
  lastActivityAt: FieldValue.serverTimestamp(),
}, { merge: true });

// Award world-completion certificate if newly 100%
if (percent === 100 && !previousWorldProgress?.certificateEarned) {
  await childRef.update({ certificateCount: FieldValue.increment(1) });
}
```

### 1c. Badge engine
Checks all badge conditions after each activity completion.
Awards badge documents if conditions are met and badge not already awarded.

**Badge catalogue (v1):**

| Badge | Trigger condition |
|---|---|
| `first-star` | activitiesCompleted == 1 |
| `five-star` | activitiesCompleted == 5 |
| `fifty-star` | activitiesCompleted == 50 |
| `century` | activitiesCompleted == 100 |
| `perfect` | perfectBonus == true (first time) |
| `speed-demon` | completedInMs < 15000 (first time) |
| `world-{slug}` | worldProgress[worldSlug].percentComplete == 100 |
| `explorer` | activitiesCompleted across all worlds >= 1 for each of 9 worlds |
| `path-{pathCode}` | pathProgress[pathCode].status == 'completed' |
| `streak-7` | dailySessions with activitiesCompleted > 0 for 7 consecutive dates |
| `xp-500` | totalXP >= 500 |
| `xp-1000` | totalXP >= 1000 |
| `xp-5000` | totalXP >= 5000 |

```javascript
const childData = (await childRef.get()).data();
const existingBadges = new Set(
  (await getDocs(collection(childRef, 'badges'))).docs.map(d => d.id)
);

const BADGE_CHECKS = [
  { id: 'first-star',  cond: childData.activitiesCompleted >= 1 },
  { id: 'fifty-star',  cond: childData.activitiesCompleted >= 50 },
  { id: 'century',     cond: childData.activitiesCompleted >= 100 },
  { id: 'xp-1000',     cond: childData.totalXP >= 1000 },
  // ... etc
];

for (const { id, cond } of BADGE_CHECKS) {
  if (cond && !existingBadges.has(id)) {
    await childRef.collection('badges').doc(id).set({
      name: BADGE_META[id].name, icon: BADGE_META[id].icon,
      category: BADGE_META[id].category, earnedAt: FieldValue.serverTimestamp(),
    });
    await childRef.update({ badgeCount: FieldValue.increment(1) });
  }
}
```

### 1d. Roster sync
If this child is enrolled in any class, update their denormalized roster summary:

```javascript
const rosterQuery = await getDocs(
  query(collectionGroup('roster'), where('childId', '==', childId))
);
for (const rosterDoc of rosterQuery.docs) {
  await rosterDoc.ref.update({
    totalXP:             childData.totalXP,
    totalCoins:          childData.totalCoins,
    activitiesCompleted: childData.activitiesCompleted,
    level:               calcLevel(childData.totalXP),
    badgeCount:          childData.badgeCount,
    lastActiveAt:        FieldValue.serverTimestamp(),
    worldProgress:       worldProgressSnapshot, // all 9 worlds summary
  });
}
```

---

## 2. `onChildDeleted`

**Trigger:** `onDocumentDeleted('users/{uid}/children/{childId}')`

Firestore does not cascade-delete subcollections when a parent document is deleted.
This function performs the full GDPR Article 17 erasure.

```javascript
async function deleteCollection(collRef, batchSize = 499) {
  const snap = await getDocs(query(collRef, limit(batchSize)));
  if (snap.empty) return;
  const batch = admin.firestore().batch();
  snap.docs.forEach(d => batch.delete(d.ref));
  await batch.commit();
  // Recurse for large collections
  await deleteCollection(collRef, batchSize);
}

// Delete all subcollections under the child
const childRef = `users/${uid}/children/${childId}`;
const SUBCOLLECTIONS = ['activityProgress', 'worldProgress', 'badges', 'dailySessions', 'pathProgress'];
for (const sub of SUBCOLLECTIONS) {
  await deleteCollection(admin.firestore().collection(`${childRef}/${sub}`));
}

// Remove this child from all teacher roster entries
const rosterQuery = await getDocs(
  query(collectionGroup('roster'), where('childId', '==', childId))
);
const batch = admin.firestore().batch();
rosterQuery.docs.forEach(d => batch.delete(d.ref));
await batch.commit();
```

---

## 3. `resetScreenTimeDaily`

**Trigger:** Cron `0 1 * * *` (00:01 in UTC — adjust for target timezone)

Resets `screenTimeToday` to 0 for all children where `screenTimeTodayDate` is not today.
Uses Firestore collection group queries with batched writes.

```javascript
const today    = new Date().toISOString().split('T')[0];
const children = await getDocs(
  query(collectionGroup('children'), where('screenTimeTodayDate', '!=', today))
);
// Batch update in groups of 499
for (const chunk of chunks(children.docs, 499)) {
  const batch = admin.firestore().batch();
  chunk.forEach(d => batch.update(d.ref, { screenTimeToday: 0, screenTimeTodayDate: today }));
  await batch.commit();
}
```

---

## 4. `sendWeeklyReports`

**Trigger:** Cron `0 8 * * 0` (08:00 UTC every Sunday)

For each parent with `weeklyReportEnabled: true`:
1. Fetch all children under the parent
2. For each child: aggregate last 7 days of dailySessions + worldProgress
3. Render an HTML email template (Handlebars)
4. Send via Firebase Extensions: Trigger Email (or SendGrid/Mailgun via secret manager)

**Email sections:**
- Summary: total XP, coins, activities this week vs last week (% change)
- Per-world progress bars
- New badges earned this week
- Screen time chart (7-day bar chart inline SVG)
- Recommended next activities based on world with most progress

---

## 5. `syncRosterOnProgress`

**Trigger:** Same as `onActivityCompleted` (can be merged into that function)

Kept separate in this spec for clarity. Updates worldProgress map on roster entry:
```javascript
worldProgress: {
  'alphabet-island': { completed: 12, total: 110, percent: 11 },
  'math-mountain':   { completed: 7,  total: 130, percent: 5  },
  // ... all 9 worlds
}
```
Teachers use this for the skill-gap analytics view.

---

## 6. `deleteChildData` (HTTPS Callable)

**Endpoint:** `https://{region}-{project}.cloudfunctions.net/deleteChildData`
**Auth:** Firebase Auth token required; caller must be the child's parentUid.

```javascript
exports.deleteChildData = onCall(async (request) => {
  const { childId } = request.data;
  const parentUid   = request.auth.uid;

  // Verify caller is the parent of this child
  const childDoc = await admin.firestore().doc(`users/${parentUid}/children/${childId}`).get();
  if (!childDoc.exists) throw new HttpsError('not-found', 'Child profile not found.');

  // Trigger the cascade delete (same logic as onChildDeleted)
  await performCascadeDelete(parentUid, childId);
  return { success: true };
});
```

---

## 7. `endSessionBeacon` (HTTPS Callable)

For reliable session-end writes on page unload, the client calls this via:
```javascript
navigator.sendBeacon('/api/session-end', JSON.stringify({ childId, elapsedMs }));
```

This function receives the beacon and writes the screen-time update:
```javascript
exports.endSessionBeacon = onRequest(async (req, res) => {
  const { uid, childId, elapsedMs } = JSON.parse(req.body);
  const elapsedMinutes = Math.round(elapsedMs / 60000);
  if (elapsedMinutes < 1) { res.sendStatus(204); return; }
  // ... write to Firestore
  res.sendStatus(204);
});
```

---

## Required Firestore Indexes

Add to `firestore.indexes.json`:

```json
{
  "indexes": [
    {
      "collectionGroup": "activityProgress",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "worldSlug",    "order": "ASCENDING"  },
        { "fieldPath": "completedAt",  "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "activityProgress",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "completedAt",  "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "roster",
      "queryScope": "COLLECTION_GROUP",
      "fields": [
        { "fieldPath": "childId",    "order": "ASCENDING"  }
      ]
    },
    {
      "collectionGroup": "roster",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "isActive",   "order": "ASCENDING"  },
        { "fieldPath": "totalXP",    "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "classes",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "teacherUid", "order": "ASCENDING"  },
        { "fieldPath": "createdAt",  "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "children",
      "queryScope": "COLLECTION_GROUP",
      "fields": [
        { "fieldPath": "screenTimeTodayDate", "order": "ASCENDING" }
      ]
    }
  ]
}
```

---

## Data Retention Policy (GDPR / COPPA)

| Data | Retention | Deletion trigger |
|---|---|---|
| User account | Until account deleted | GDPR Art. 17 request or 2-year inactivity |
| Child profile + progress | Until child deleted or parent deletes account | `deleteChildData` callable |
| Daily sessions | 1 year rolling | Cloud Function daily cleanup |
| Teacher class data | Until class deleted by teacher | Manual |
| Roster entries | Until student removed or parent withdraws consent | `deleteRosterEntry` |
| Weekly email logs | 90 days | Extension config |

---

*Kivora Firebase Functions Spec v1.0 · June 2026*
*Paired with: firebase-config.js · firebase-service.js · firestore.rules*
